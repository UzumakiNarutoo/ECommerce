from django.apps import AppConfig


class ShoppingcartadminConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'ShoppingCartAdmin'
